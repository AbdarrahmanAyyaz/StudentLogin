#pragma once
#include "persontype.h"
#include "datetype.h"
#include "coursetype.h"
#include <fstream>
#include <iomanip>
#include <sstream>
class FacultyType : public PersonType
{
private:
    string facultyID;
    string departmentName;
};