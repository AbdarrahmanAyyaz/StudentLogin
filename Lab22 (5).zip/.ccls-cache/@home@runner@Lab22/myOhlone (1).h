#pragma once
#include <vector>
#include "personType.h"
#include "LoginInfo.h"
#include "courseType.h"

using namespace std;
enum ohloneMenu
{ 
    Display = 'l', View = 'v', Add = 'a', Edito = 'e', Delete = 'd', Exit = 'x' 
};

class MyOhlone {
public:
    // doAuthentication
    char loginMenu();
    bool doLogin();

    // doCourses
    void doDisplay(vector <CourseDetail>);
    void doView(vector <CourseDetail>);
    void doAdd(vector <CourseDetail>&);
    void doEdit(vector <CourseDetail>&);
    void doDelete(vector <CourseDetail>&);
    void readData(vector <CourseDetail>);
    vector <CourseDetail> LoadData();
    MyOhlone();
    ~MyOhlone();

private:
    void readUsers(string usercsv);
    void readCourses(string coursecsv);

    vector<CourseType*>* list;
    vector <LoginInfo> users;
    PersonType student;
    LoginInfo loginInfo;
};
