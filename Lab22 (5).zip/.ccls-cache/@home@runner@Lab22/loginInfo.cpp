#include "loginInfo.h"
using namespace std;

vector <LoginInfo> LoginInfo::LoadData()
{
    vector <LoginInfo> obj;

    LoginInfo loginfo;
    string line;
    int lineNum = 0;
    // File pointer
    fstream fin;

    // Open an existing file
    fin.open("users.csv", ios::in);

    string sDay, sMonth, sYear, sTime, sHH, sMM, sSS;
    DateTime d1;
    
    while (getline(fin, line))
    {
        istringstream iss(line);
        lineNum++;

        // Try to extract login Information from the line. If successful, ok will be true.
        bool ok = false;
        do
        {
            if (!getline(iss, loginfo.username, ','))
                break;
            if (!getline(iss, loginfo.password, ','))
                break;
            if (!getline(iss, sMonth, '-'))
                break;
            if (!getline(iss, sDay, '-'))
                break;  //stop getting input at '-'
            if (!getline(iss, sYear, ' '))
                break;
            if (!getline(iss, sHH, ':'))
                break;
            if (!getline(iss, sMM, ':'))
                break;
            if (!getline(iss, sSS, ','))
                break;
            loginfo.loginDateTime.SetMonth(atoi(sMonth.c_str()));
            loginfo.loginDateTime.SetDay(atoi(sDay.c_str()));
            loginfo.loginDateTime.SetYear(atoi(sYear.c_str()));
            loginfo.loginDateTime.SetHours(atoi(sHH.c_str()));
            loginfo.loginDateTime.SetMinutes(atoi(sMM.c_str()));
            loginfo.loginDateTime.SetSeconds(atoi(sSS.c_str()));

            if (!getline(iss, sMonth, '-'))
                break;
            if (!getline(iss, sDay, '-'))
                break;  //stop getting input at '-'
            if (!getline(iss, sYear, ' '))
                break;
            if (!getline(iss, sHH, ':'))
                break;
            if (!getline(iss, sMM, ':'))
                break;
            if (!getline(iss, sSS, '\n'))
                break;
            loginfo.logoutDateTime.SetMonth(atoi(sMonth.c_str()));
            loginfo.logoutDateTime.SetDay(atoi(sDay.c_str()));
            loginfo.logoutDateTime.SetYear(atoi(sYear.c_str()));
            loginfo.logoutDateTime.SetHours(atoi(sHH.c_str()));
            loginfo.logoutDateTime.SetMinutes(atoi(sMM.c_str()));
            loginfo.logoutDateTime.SetSeconds(atoi(sSS.c_str()));
            ok = true;
        } while (false);
        // If all is well, add the user to user-vector.
        if (ok)
        {
            obj.push_back(loginfo);
        }
        else
        {
            cout << "Failed to parse line " << lineNum << ": " << line << endl;
        }
    }
    fin.close();
    return obj;
}

void LoginInfo::DisplayRecord(vector <LoginInfo> obj)
{
    int usernumber = 1;
    for (int i = 0; i < obj.size(); i++)
    {
        cout << setw(40) << setfill('+') << " " << endl;
        cout << setfill(' ');
        cout << "User Number " << usernumber << ":" << endl;
        cout << "Name: " << setw(18) << " " << obj[i].getUser() << "\nPassword: " << setw(18) << " " << obj[i].getPass() << "\nLogin Date: " << setw(12) << " " << obj[i].loginDateTime.GetMonth() << "-" << obj[i].loginDateTime.GetDay() << "-" << obj[i].loginDateTime.GetYear() << " " << obj[i].loginDateTime.GetHours() << ":" << obj[i].loginDateTime.GetMinutes() << ":" << obj[i].loginDateTime.GetSeconds() << "\nLogout Date: " << setw(12) << " " << obj[i].logoutDateTime.GetMonth() << "-" << obj[i].logoutDateTime.GetDay() << "-" << obj[i].logoutDateTime.GetYear() << " " << obj[i].logoutDateTime.GetHours() << ":" << obj[i].logoutDateTime.GetMinutes() << ":" << obj[i].logoutDateTime.GetSeconds() << endl;
        cout << setw(40) << setfill('+') << " " << endl;
        cout << setfill(' ');
        usernumber++;
    }
}

bool LoginInfo::UserAuthentication(string user, string pass, vector <LoginInfo> obj)
{
    int count = 0;
    for (int i = 0; i < obj.size(); i++)
    {
        if ((obj[i].getUser().compare(user) == 0) && (obj[i].getPass().compare(pass) == 0))
        {
            break;
        }
        else
        {
            count++;
        }
    }
    if (count >= 0 && count < obj.size())
    {
        cout << user << " is authenticated!" << endl;
        return true;
    }
    else
    {
        cout << "Either Username or password is wrong or not found in the database\n";
        return false;
    }
}

void LoginInfo::CreateAccount(vector <LoginInfo>& obj)
{
    struct tm newtime;
    __time32_t long_time;
    //char timebuf[26];
    errno_t err;
    _time32(&long_time);
    // Convert to local time.
    err = _localtime32_s(&newtime, &long_time);
    //time_t ttime = time(0);
    //tm* local_time = localtime(&ttime);
    

    LoginInfo newuser;
    // file pointer
    fstream fout;

    // opens an existing csv file or creates a new file.
    fout.open("users.csv", ios::out | ios::app);

    cout << "Enter the details of a new user:" << endl;
    
    cout << "UserName: ";
    string nuser;
    cin >> nuser;
    newuser.setUser(nuser);
    cout << "Password: ";
    string npass;
    cin >> npass;
    newuser.setPass(npass);
    //newuser.loginDateTime.SetMonth(1 + local_time->tm_mon);
    newuser.loginDateTime.SetMonth(1 + newtime.tm_mon);
    newuser.loginDateTime.SetDay(newtime.tm_mday);
    newuser.loginDateTime.SetYear(1900 + newtime.tm_year);
    newuser.loginDateTime.SetHours(newtime.tm_hour);
    newuser.loginDateTime.SetMinutes(newtime.tm_min);
    newuser.loginDateTime.SetSeconds(newtime.tm_sec);
    newuser.logoutDateTime.SetMonth(1 + newtime.tm_mon);
    newuser.logoutDateTime.SetDay(newtime.tm_mday);
    newuser.logoutDateTime.SetYear(1900 + newtime.tm_year);
    newuser.logoutDateTime.SetHours(newtime.tm_hour);
    newuser.logoutDateTime.SetMinutes(newtime.tm_min);
    newuser.logoutDateTime.SetSeconds(newtime.tm_sec);
    obj.push_back(newuser);
    // Insert the data to file
    fout << newuser.getUser() << ","
        << newuser.getPass() << ","
        << newuser.loginDateTime.GetMonth() << "-"
        << newuser.loginDateTime.GetDay() << "-"
        << newuser.loginDateTime.GetYear() << " "
        << newuser.loginDateTime.GetHours() << ":"
        << newuser.loginDateTime.GetMinutes() << ":"
        << newuser.loginDateTime.GetSeconds() << ","
        << newuser.logoutDateTime.GetMonth() << "-"
        << newuser.logoutDateTime.GetDay() << "-"
        << newuser.logoutDateTime.GetYear() << " "
        << newuser.logoutDateTime.GetHours() << ":"
        << newuser.logoutDateTime.GetMinutes() << ":"
        << newuser.logoutDateTime.GetSeconds() << ","
        << "\n";
    cout << "New User is successfully created!" << endl;
    fout.close();
}

void LoginInfo::ResetPassword(vector <LoginInfo>& obj)
{
    // File pointer
    fstream fin, fout;

    // Open an existing record
    fin.open("users.csv", ios::in);

    // Create a new file to store updated data
    fout.open("usersnew.csv", ios::out);

    // Get the username of which the password is being reset
    string userna, newpass, renewpass;
    cout << "Enter the Username: ";
    cin >> userna;

    int count = 0;
    for (int i = 0; i < obj.size(); i++)
    {
        if (obj[i].getUser().compare(userna) == 0)
        {
            break;
        }
        else
        {
            count++;
        }
    }
    if (count >= 0 && count < obj.size())
    {
        do
        {
            cout << "Enter the new password: ";
            cin >> newpass;
            cout << "Re-enter the new password: ";
            cin >> renewpass;
            if (renewpass.compare(newpass) == 0)
            {
                obj[count].setPass(newpass);
                break;
            }
            else
            {
                cout << "Both passwords are not matched, please try again!" << endl;
            }
        } while (true);
               
        for (int index = 0; index < obj.size(); index++)
        {
            // Insert the data to file
            fout << obj[index].getUser() << ","
                << obj[index].getPass() << ","
                << obj[index].loginDateTime.GetMonth() << "-"
                << obj[index].loginDateTime.GetDay() << "-"
                << obj[index].loginDateTime.GetYear() << " "
                << obj[index].loginDateTime.GetHours() << ":"
                << obj[index].loginDateTime.GetMinutes() << ":"
                << obj[index].loginDateTime.GetSeconds() << ","
                << obj[index].logoutDateTime.GetMonth() << "-"
                << obj[index].logoutDateTime.GetDay() << "-"
                << obj[index].logoutDateTime.GetYear() << " "
                << obj[index].logoutDateTime.GetHours() << ":"
                << obj[index].logoutDateTime.GetMinutes() << ":"
                << obj[index].logoutDateTime.GetSeconds() << ","
                << "\n";
        }

        fin.close();
        fout.close();

        // removing the existing file
        remove("users.csv");
        int status;
        // renaming the updated file with the existing file name
        status = rename("usersnew.csv", "users.csv");
        if (status == 0)
        {
            cout << "New Password is updated! " << endl;
        }
    }
    else
    {
        cout << "Record not found\n";
    }
}

void LoginInfo::UpdateLoginDateTime(string username, vector <LoginInfo>& obj)
{
    struct tm newtime;
    __time32_t long_time;
    errno_t err;
    _time32(&long_time);
    // Convert to local time.
    err = _localtime32_s(&newtime, &long_time);

    // File pointer
    fstream fin, fout;

    // Open an existing record
    fin.open("users.csv", ios::in);

    // Create a new file to store updated data
    fout.open("usersnew.csv", ios::out);

    //LoginInfo editlogindatetime;
    
    int count = 0;
    for (int i = 0; i < obj.size(); i++)
    {
        if (obj[i].getUser().compare(username) == 0)
        {
            break;
        }
        else
        {
            count++;
        }
    }
    if (count >= 0 && count < obj.size())
    {
        obj[count].loginDateTime.SetMonth(1 + newtime.tm_mon);
        obj[count].loginDateTime.SetDay(newtime.tm_mday);
        obj[count].loginDateTime.SetYear(1900 + newtime.tm_year);
        obj[count].loginDateTime.SetHours(newtime.tm_hour);
        obj[count].loginDateTime.SetMinutes(newtime.tm_min);
        obj[count].loginDateTime.SetSeconds(newtime.tm_sec);
        for (int index = 0; index < obj.size(); index++)
        {
            // Insert the data to file
            fout << obj[index].getUser() << ","
                << obj[index].getPass() << ","
                << obj[index].loginDateTime.GetMonth() << "-"
                << obj[index].loginDateTime.GetDay() << "-"
                << obj[index].loginDateTime.GetYear() << " "
                << obj[index].loginDateTime.GetHours() << ":"
                << obj[index].loginDateTime.GetMinutes() << ":"
                << obj[index].loginDateTime.GetSeconds() << ","
                << obj[index].logoutDateTime.GetMonth() << "-"
                << obj[index].logoutDateTime.GetDay() << "-"
                << obj[index].logoutDateTime.GetYear() << " "
                << obj[index].logoutDateTime.GetHours() << ":"
                << obj[index].logoutDateTime.GetMinutes() << ":"
                << obj[index].logoutDateTime.GetSeconds() << ","
                << "\n";
        }

        fin.close();
        fout.close();

        // removing the existing file
        remove("users.csv");
        int status;
        // renaming the updated file with the existing file name
        status = rename("usersnew.csv", "users.csv");
        if (status == 0)
        {
            cout << "Login Time is updated! " << endl;
        }
    }
    else
    {
        cout << "Record not found\n";
    }
}

void LoginInfo::UpdateLogoutDateTime(string username, vector <LoginInfo>& obj)
{
    struct tm newtime;
    __time32_t long_time;
    errno_t err;
    _time32(&long_time);
    // Convert to local time.
    err = _localtime32_s(&newtime, &long_time);

    // File pointer
    fstream fin, fout;

    // Open an existing record
    fin.open("users.csv", ios::in);

    // Create a new file to store updated data
    fout.open("usersnew.csv", ios::out);

    //LoginInfo editlogindatetime;

    int count = 0;
    for (int i = 0; i < obj.size(); i++)
    {
        if (obj[i].getUser().compare(username) == 0)
        {
            break;
        }
        else
        {
            count++;
        }
    }
    if (count >= 0 && count < obj.size())
    {
        obj[count].logoutDateTime.SetMonth(1 + newtime.tm_mon);
        obj[count].logoutDateTime.SetDay(newtime.tm_mday);
        obj[count].logoutDateTime.SetYear(1900 + newtime.tm_year);
        obj[count].logoutDateTime.SetHours(newtime.tm_hour);
        obj[count].logoutDateTime.SetMinutes(newtime.tm_min);
        obj[count].logoutDateTime.SetSeconds(newtime.tm_sec);
        for (int index = 0; index < obj.size(); index++)
        {
            // Insert the data to file
            fout << obj[index].getUser() << ","
                << obj[index].getPass() << ","
                << obj[index].loginDateTime.GetMonth() << "-"
                << obj[index].loginDateTime.GetDay() << "-"
                << obj[index].loginDateTime.GetYear() << " "
                << obj[index].loginDateTime.GetHours() << ":"
                << obj[index].loginDateTime.GetMinutes() << ":"
                << obj[index].loginDateTime.GetSeconds() << ","
                << obj[index].logoutDateTime.GetMonth() << "-"
                << obj[index].logoutDateTime.GetDay() << "-"
                << obj[index].logoutDateTime.GetYear() << " "
                << obj[index].logoutDateTime.GetHours() << ":"
                << obj[index].logoutDateTime.GetMinutes() << ":"
                << obj[index].logoutDateTime.GetSeconds() << ","
                << "\n";
        }

        fin.close();
        fout.close();

        // removing the existing file
        remove("users.csv");
        int status;
        // renaming the updated file with the existing file name
        status = rename("usersnew.csv", "users.csv");
        if (status == 0)
        {
            cout << "Logout Time is updated! " << endl;
        }
    }
    else
    {
        cout << "Record not found\n";
    }
}

void LoginInfo::setUser(string ustr)
{
    username = ustr;
}

void LoginInfo::setPass(string pstr)
{
    password = pstr;
}


string LoginInfo::getUser()
{
    return username;
}

string LoginInfo::getPass()
{
    return password;
}
