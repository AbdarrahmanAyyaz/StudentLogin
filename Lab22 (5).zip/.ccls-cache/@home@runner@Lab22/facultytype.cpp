//#include "FacultyType.h"
//using namespace std;
//void FacultyType::GetInformation()
//{
//    string line;
//    int lineNum = 0;
//    // File pointer
//    fstream fin;
//
//    // Open an existing file
//    fin.open("courses.csv", ios::in);
//    while (getline(fin, line))
//    {
//        istringstream iss(line);
//        lineNum++;
//
//        // Try to extract course data from the line. If successful, ok will be true.
//        bool ok = false;
//        string str, sMonth, sDay, sYear;
//        do
//        {
//            //string val;
//            if (!getline(iss, str, ','))
//                break;
//            if (!getline(iss, str, ','))
//                break;
//            if (!getline(iss, sMonth, '-')) break;
//            if (!getline(iss, sDay, '-')) break;
//            if (!getline(iss, sYear, ',')) break;
//            startdate.SetMonth(atoi(sMonth.c_str()));
//            startdate.SetDay(atoi(sDay.c_str()));
//            startdate.SetYear(atoi(sYear.c_str()));
//            if (!getline(iss, sMonth, '-')) break;
//            if (!getline(iss, sDay, '-')) break;
//            if (!getline(iss, sYear, ',')) break;
//            enddate.SetMonth(atoi(sMonth.c_str()));
//            enddate.SetDay(atoi(sDay.c_str()));
//            enddate.SetYear(atoi(sYear.c_str()));
//            if (!getline(iss, str, ',')) break;
//            if (!getline(iss, str, ','))
//                break;
//            if (!getline(iss, str, ',')) break;
//            if (!getline(iss, str, ',')) break;
//            if (!getline(iss, str, ',')) break;
//            if (!getline(iss, str, ',')) break;
//            SetlastName(str);
//            if (!getline(iss, str, ','))
//                break;
//            ok = true;
//            cout << "Instructor: " << getlastName() << endl;
//            cout << "Start Date: " << startdate.GetMonth() << "-" << startdate.GetDay() << "-" << startdate.GetYear() << endl;
//            cout << "End Date: " << enddate.GetMonth() << "-" << enddate.GetDay() << "-" << enddate.GetYear() << endl;
//        } while (false);
//    }
//    fin.close();
//}